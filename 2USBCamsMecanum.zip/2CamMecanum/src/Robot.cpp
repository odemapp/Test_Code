/* Example of running multiple USB cameras off of the RoboRio.
 * FRC Team #116  -  Epsilon Delta
 * Herndon High School
 * Herndon, VA
 *
 * Author:           Mike Anderson
 * Email:            robot_maker12@verizon.net
 * Chief Delphi ID:  taichichuan
 *
 * This is probably worth what you paid for it.  ;-)
 */
#include "WPILib.h"
#include "CameraFeeds.h"

/**
 * Uses IMAQdx to manually acquire a new image each frame, and annotate the image by drawing
 * a circle on it, and show it on the FRC Dashboard.
 */
class IntermediateVisionRobot: public SampleRobot {

	CANTalon *m_motor1;
	CANTalon *m_motor2;
	CANTalon *m_motor3;
	CANTalon *m_motor4;

	// Camerafeeds
	CAMERAFEEDS *cameraFeeds;

	// Joystick with which to control the relay.
	Joystick *m_stick;

	RobotDrive *robotDrive;	// robot drive system

	// Numbers of the buttons to be used for controlling the Relay.
	const int kCam0Button = 1;
	const int kCam1Button = 2;
	const bool kError = false;
	const bool kOk = true;

public:
	void RobotInit() override {
		m_motor1 = new CANTalon(1);
		m_motor2 = new CANTalon(2);
		m_motor3 = new CANTalon(3);
		m_motor4 = new CANTalon(4);

		robotDrive = new RobotDrive(m_motor1, m_motor3, m_motor2, m_motor4);
		robotDrive->SetSafetyEnabled(false);
		robotDrive->SetInvertedMotor(RobotDrive::kFrontLeftMotor, true);	// invert the left side motors
		robotDrive->SetInvertedMotor(RobotDrive::kRearLeftMotor, true);	// you may need to change or remove this to match your robot

		m_stick = new Joystick(0); // Use joystick on port 0.

		cameraFeeds = new CAMERAFEEDS(m_stick);
		cameraFeeds->init();

	}

	void OperatorControl() override {
		// grab an image, draw the circle, and provide it for the camera server which will
		// in turn send it to the dashboard.
		while (IsOperatorControl() && IsEnabled()) {

			robotDrive->MecanumDrive_Cartesian(m_stick->GetX(), m_stick->GetY(), m_stick->GetZ());
			cameraFeeds->run();

		}
		// stop image acquisition
		cameraFeeds->end();
	}
};

START_ROBOT_CLASS(IntermediateVisionRobot);

